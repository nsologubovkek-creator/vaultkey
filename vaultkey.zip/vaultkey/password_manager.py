#!/usr/bin/env python3
"""
🔐 VaultKey - Gestionnaire de mots de passe portable
Stockage chiffré, interface élégante, 100% portable sur clé USB
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
import os
import sys
import hashlib
import base64
import secrets
import string
from datetime import datetime
from pathlib import Path

# ── Chiffrement simple sans dépendances externes ────────────────────────────
def derive_key(password: str, salt: bytes) -> bytes:
    """Dérive une clé 32 bytes depuis un mot de passe."""
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 200_000)
    return dk

def xor_encrypt(data: bytes, key: bytes) -> bytes:
    """Chiffrement XOR avec extension de clé via SHA-256."""
    result = bytearray()
    key_stream = b""
    i = 0
    for byte in data:
        if i >= len(key_stream):
            key_stream = hashlib.sha256(key + i.to_bytes(4, 'big')).digest()
            i = 0
        result.append(byte ^ key_stream[i])
        i += 1
    return bytes(result)

def encrypt_data(plaintext: str, password: str) -> str:
    salt = secrets.token_bytes(32)
    key = derive_key(password, salt)
    data = plaintext.encode('utf-8')
    encrypted = xor_encrypt(data, key)
    # Ajoute un HMAC pour vérifier l'intégrité
    mac = hashlib.hmac_new if hasattr(hashlib, 'hmac_new') else None
    import hmac
    tag = hmac.new(key, encrypted, hashlib.sha256).digest()
    payload = salt + tag + encrypted
    return base64.b64encode(payload).decode('ascii')

def decrypt_data(ciphertext: str, password: str) -> str:
    import hmac
    payload = base64.b64decode(ciphertext.encode('ascii'))
    salt = payload[:32]
    tag = payload[32:64]
    encrypted = payload[64:]
    key = derive_key(password, salt)
    expected_tag = hmac.new(key, encrypted, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("Mot de passe incorrect ou données corrompues")
    return xor_encrypt(encrypted, key).decode('utf-8')

# ── Chemin du fichier de données (portable) ─────────────────────────────────
def get_data_path() -> Path:
    """Retourne le chemin du fichier de données à côté du script."""
    script_dir = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent
    return script_dir / "vaultkey_data.enc"

def get_config_path() -> Path:
    script_dir = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent
    return script_dir / "vaultkey_config.json"

# ── Couleurs & polices ───────────────────────────────────────────────────────
BG_DARK    = "#0D0F14"
BG_CARD    = "#13161E"
BG_INPUT   = "#1A1D27"
ACCENT     = "#6C63FF"
ACCENT2    = "#A78BFA"
SUCCESS    = "#34D399"
DANGER     = "#F87171"
TEXT_MAIN  = "#E8E8F0"
TEXT_DIM   = "#6B7280"
BORDER     = "#2A2D3E"

FONT_TITLE  = ("Segoe UI", 22, "bold")
FONT_SUB    = ("Segoe UI", 11)
FONT_LABEL  = ("Segoe UI", 10, "bold")
FONT_INPUT  = ("Consolas", 11)
FONT_SMALL  = ("Segoe UI", 9)
FONT_BTN    = ("Segoe UI", 10, "bold")
FONT_MONO   = ("Consolas", 12)

# ════════════════════════════════════════════════════════════════════════════
class VaultApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🔐 VaultKey")
        self.geometry("980x680")
        self.minsize(820, 580)
        self.configure(bg=BG_DARK)
        self.resizable(True, True)

        self.master_password = None
        self.entries = []          # liste de dicts {site, username, password, created}
        self.filtered = []
        self.selected_idx = None
        self._show_pw = {}         # {row_idx: bool}

        # Centrer la fenêtre
        self.update_idletasks()
        x = (self.winfo_screenwidth()  - 980) // 2
        y = (self.winfo_screenheight() - 680) // 2
        self.geometry(f"980x680+{x}+{y}")

        self._build_styles()
        self._show_login_screen()

    # ── Styles ttk ────────────────────────────────────────────────────────
    def _build_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")

        style.configure("TFrame",       background=BG_DARK)
        style.configure("Card.TFrame",  background=BG_CARD)
        style.configure("TLabel",       background=BG_DARK, foreground=TEXT_MAIN,
                        font=FONT_SUB)
        style.configure("Card.TLabel",  background=BG_CARD,  foreground=TEXT_MAIN,
                        font=FONT_SUB)
        style.configure("Dim.TLabel",   background=BG_CARD,  foreground=TEXT_DIM,
                        font=FONT_SMALL)
        style.configure("Title.TLabel", background=BG_DARK, foreground=TEXT_MAIN,
                        font=FONT_TITLE)

        style.configure("Accent.TButton",
            background=ACCENT, foreground="#FFFFFF",
            font=FONT_BTN, relief="flat", padding=(14, 8))
        style.map("Accent.TButton",
            background=[("active", ACCENT2), ("pressed", "#5046E5")])

        style.configure("Ghost.TButton",
            background=BG_INPUT, foreground=TEXT_MAIN,
            font=FONT_BTN, relief="flat", padding=(12, 7))
        style.map("Ghost.TButton",
            background=[("active", BORDER), ("pressed", BG_CARD)])

        style.configure("Danger.TButton",
            background="#3D1515", foreground=DANGER,
            font=FONT_BTN, relief="flat", padding=(10, 6))
        style.map("Danger.TButton",
            background=[("active", "#5A1F1F")])

        style.configure("Treeview",
            background=BG_CARD, foreground=TEXT_MAIN,
            fieldbackground=BG_CARD, font=("Consolas", 10),
            rowheight=36, borderwidth=0, relief="flat")
        style.configure("Treeview.Heading",
            background=BG_INPUT, foreground=ACCENT2,
            font=("Segoe UI", 10, "bold"), borderwidth=0, relief="flat")
        style.map("Treeview",
            background=[("selected", ACCENT)],
            foreground=[("selected", "#FFFFFF")])

        style.configure("Vertical.TScrollbar",
            background=BG_INPUT, troughcolor=BG_DARK,
            arrowcolor=TEXT_DIM, relief="flat")

    # ════════════════════════════════════════════════════════════════════════
    # ÉCRAN DE CONNEXION
    # ════════════════════════════════════════════════════════════════════════
    def _show_login_screen(self):
        for w in self.winfo_children():
            w.destroy()

        container = tk.Frame(self, bg=BG_DARK)
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Logo / titre
        tk.Label(container, text="🔐", font=("Segoe UI", 48),
                 bg=BG_DARK, fg=ACCENT).pack(pady=(0, 8))
        tk.Label(container, text="VaultKey",
                 font=("Segoe UI", 32, "bold"), bg=BG_DARK, fg=TEXT_MAIN).pack()
        tk.Label(container, text="Gestionnaire de mots de passe sécurisé",
                 font=FONT_SUB, bg=BG_DARK, fg=TEXT_DIM).pack(pady=(4, 32))

        # Carte de connexion
        card = tk.Frame(container, bg=BG_CARD,
                        highlightbackground=BORDER, highlightthickness=1)
        card.pack(ipadx=32, ipady=28, padx=8)

        is_new = not get_data_path().exists()
        title_text = "Créer un coffre-fort" if is_new else "Déverrouiller le coffre-fort"
        tk.Label(card, text=title_text,
                 font=("Segoe UI", 14, "bold"), bg=BG_CARD, fg=TEXT_MAIN).pack(pady=(0, 20))

        tk.Label(card, text="Mot de passe maître",
                 font=FONT_LABEL, bg=BG_CARD, fg=ACCENT2).pack(anchor="w", padx=4)

        pw_frame = tk.Frame(card, bg=BG_INPUT,
                            highlightbackground=ACCENT, highlightthickness=1)
        pw_frame.pack(fill="x", ipady=4, pady=(4, 16))

        pw_var = tk.StringVar()
        pw_entry = tk.Entry(pw_frame, textvariable=pw_var, show="●",
                            font=FONT_MONO, bg=BG_INPUT, fg=TEXT_MAIN,
                            insertbackground=ACCENT, relief="flat",
                            bd=6, width=28)
        pw_entry.pack(side="left", fill="x", expand=True)

        show_var = tk.BooleanVar(value=False)
        def toggle_show():
            pw_entry.config(show="" if show_var.get() else "●")
        tk.Checkbutton(pw_frame, text="👁", variable=show_var, command=toggle_show,
                       bg=BG_INPUT, fg=TEXT_DIM, activebackground=BG_INPUT,
                       selectcolor=BG_INPUT, relief="flat", cursor="hand2").pack(side="right", padx=4)

        if is_new:
            tk.Label(card, text="Confirmer le mot de passe",
                     font=FONT_LABEL, bg=BG_CARD, fg=ACCENT2).pack(anchor="w", padx=4)
            cf_frame = tk.Frame(card, bg=BG_INPUT,
                                highlightbackground=BORDER, highlightthickness=1)
            cf_frame.pack(fill="x", ipady=4, pady=(4, 16))
            cf_var = tk.StringVar()
            cf_entry = tk.Entry(cf_frame, textvariable=cf_var, show="●",
                                font=FONT_MONO, bg=BG_INPUT, fg=TEXT_MAIN,
                                insertbackground=ACCENT, relief="flat",
                                bd=6, width=28)
            cf_entry.pack(fill="x")
        else:
            cf_var = None

        msg_var = tk.StringVar()
        msg_lbl = tk.Label(card, textvariable=msg_var, font=FONT_SMALL,
                           bg=BG_CARD, fg=DANGER)
        msg_lbl.pack()

        def on_unlock(event=None):
            pw = pw_var.get()
            if len(pw) < 4:
                msg_var.set("⚠ Le mot de passe doit contenir au moins 4 caractères")
                return
            if is_new:
                if pw != cf_var.get():
                    msg_var.set("⚠ Les mots de passe ne correspondent pas")
                    return
                self.master_password = pw
                self.entries = []
                self._save_data()
                self._show_vault_screen()
            else:
                try:
                    self._load_data(pw)
                    self.master_password = pw
                    self._show_vault_screen()
                except Exception:
                    msg_var.set("⚠ Mot de passe incorrect")

        btn_text = "Créer le coffre-fort" if is_new else "Déverrouiller  →"
        btn = tk.Button(card, text=btn_text,
                        command=on_unlock,
                        font=FONT_BTN, bg=ACCENT, fg="white",
                        activebackground=ACCENT2, relief="flat",
                        cursor="hand2", pady=10)
        btn.pack(fill="x", pady=(12, 0))

        pw_entry.bind("<Return>", on_unlock)
        if cf_var:
            cf_entry.bind("<Return>", on_unlock)
        pw_entry.focus_set()

        if is_new:
            tk.Label(card,
                     text="💡 Ce mot de passe chiffre toutes vos données.\n   Impossible de le récupérer si oublié.",
                     font=FONT_SMALL, bg=BG_CARD, fg=TEXT_DIM,
                     justify="left").pack(pady=(16, 0))

    # ════════════════════════════════════════════════════════════════════════
    # ÉCRAN PRINCIPAL DU COFFRE-FORT
    # ════════════════════════════════════════════════════════════════════════
    def _show_vault_screen(self):
        for w in self.winfo_children():
            w.destroy()

        # ── Sidebar gauche ────────────────────────────────────────────────
        sidebar = tk.Frame(self, bg=BG_CARD, width=220,
                           highlightbackground=BORDER, highlightthickness=1)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="🔐 VaultKey",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG_CARD, fg=TEXT_MAIN).pack(pady=(24, 4), padx=16, anchor="w")
        tk.Label(sidebar, text=f"{len(self.entries)} entrée(s)",
                 font=FONT_SMALL, bg=BG_CARD, fg=TEXT_DIM).pack(padx=16, anchor="w")

        ttk.Separator(sidebar).pack(fill="x", pady=16, padx=12)

        nav_items = [
            ("🗂  Tous les mots de passe", self._tab_list),
            ("➕  Ajouter une entrée",     self._tab_add),
            ("🔑  Générer un mot de passe", self._tab_generate),
        ]
        self._nav_btns = []
        for label, cmd in nav_items:
            b = tk.Button(sidebar, text=label, command=cmd,
                          font=("Segoe UI", 10), bg=BG_CARD, fg=TEXT_MAIN,
                          activebackground=BG_INPUT, relief="flat",
                          cursor="hand2", anchor="w", padx=16, pady=10)
            b.pack(fill="x")
            self._nav_btns.append(b)

        ttk.Separator(sidebar).pack(fill="x", pady=16, padx=12)

        tk.Button(sidebar, text="🔒  Verrouiller",
                  command=self._lock,
                  font=("Segoe UI", 10), bg=BG_CARD, fg=DANGER,
                  activebackground="#3D1515", relief="flat",
                  cursor="hand2", anchor="w", padx=16, pady=10).pack(fill="x")

        # Chemin du fichier
        path_str = str(get_data_path())
        if len(path_str) > 30:
            path_str = "…" + path_str[-28:]
        tk.Label(sidebar, text=f"📁 {path_str}",
                 font=("Segoe UI", 7), bg=BG_CARD, fg=TEXT_DIM,
                 wraplength=200, justify="left").pack(side="bottom", pady=8, padx=8)

        # ── Zone de contenu principale ────────────────────────────────────
        self.content = tk.Frame(self, bg=BG_DARK)
        self.content.pack(side="left", fill="both", expand=True)

        self._tab_list()

    def _clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()

    def _highlight_nav(self, idx):
        for i, b in enumerate(self._nav_btns):
            b.config(bg=BG_INPUT if i == idx else BG_CARD,
                     fg=ACCENT2 if i == idx else TEXT_MAIN)

    # ════════════════════════════════════════════════════════════════════════
    # ONGLET : LISTE DES MOTS DE PASSE
    # ════════════════════════════════════════════════════════════════════════
    def _tab_list(self):
        self._highlight_nav(0)
        self._clear_content()

        header = tk.Frame(self.content, bg=BG_DARK)
        header.pack(fill="x", padx=28, pady=(24, 12))

        tk.Label(header, text="Tous les mots de passe",
                 font=("Segoe UI", 18, "bold"),
                 bg=BG_DARK, fg=TEXT_MAIN).pack(side="left")

        # Barre de recherche
        search_frame = tk.Frame(header, bg=BG_INPUT,
                                highlightbackground=BORDER, highlightthickness=1)
        search_frame.pack(side="right")
        tk.Label(search_frame, text="🔍", bg=BG_INPUT, fg=TEXT_DIM,
                 font=("Segoe UI", 11)).pack(side="left", padx=(8, 2))
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *_: self._refresh_list())
        tk.Entry(search_frame, textvariable=self.search_var,
                 font=FONT_SUB, bg=BG_INPUT, fg=TEXT_MAIN,
                 insertbackground=ACCENT, relief="flat",
                 bd=6, width=22).pack(side="left")

        # Tableau
        table_frame = tk.Frame(self.content, bg=BG_DARK)
        table_frame.pack(fill="both", expand=True, padx=28, pady=(0, 16))

        cols = ("site", "username", "password", "created")
        self.tree = ttk.Treeview(table_frame, columns=cols,
                                 show="headings", selectmode="browse")
        self.tree.heading("site",     text="🌐  Site")
        self.tree.heading("username", text="👤  Utilisateur")
        self.tree.heading("password", text="🔑  Mot de passe")
        self.tree.heading("created",  text="📅  Créé le")

        self.tree.column("site",     width=220, minwidth=120)
        self.tree.column("username", width=200, minwidth=120)
        self.tree.column("password", width=200, minwidth=120)
        self.tree.column("created",  width=140, minwidth=100)

        vsb = ttk.Scrollbar(table_frame, orient="vertical",
                            command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        self.tree.bind("<ButtonRelease-1>", self._on_select)
        self.tree.bind("<Double-1>",        self._on_double_click)

        self._show_pw_state = {}
        self._refresh_list()

        # Actions bas de page
        actions = tk.Frame(self.content, bg=BG_DARK)
        actions.pack(fill="x", padx=28, pady=(0, 20))

        tk.Button(actions, text="👁  Afficher / Masquer le mot de passe",
                  command=self._toggle_password,
                  font=FONT_BTN, bg=BG_INPUT, fg=TEXT_MAIN,
                  activebackground=BORDER, relief="flat",
                  cursor="hand2", padx=12, pady=7).pack(side="left", padx=(0, 8))

        tk.Button(actions, text="📋  Copier",
                  command=self._copy_password,
                  font=FONT_BTN, bg=BG_INPUT, fg=TEXT_MAIN,
                  activebackground=BORDER, relief="flat",
                  cursor="hand2", padx=12, pady=7).pack(side="left", padx=(0, 8))

        tk.Button(actions, text="✏️  Modifier",
                  command=self._edit_entry,
                  font=FONT_BTN, bg=BG_INPUT, fg=ACCENT2,
                  activebackground=BORDER, relief="flat",
                  cursor="hand2", padx=12, pady=7).pack(side="left", padx=(0, 8))

        tk.Button(actions, text="🗑  Supprimer",
                  command=self._delete_entry,
                  font=FONT_BTN, bg="#3D1515", fg=DANGER,
                  activebackground="#5A1F1F", relief="flat",
                  cursor="hand2", padx=12, pady=7).pack(side="left")

        tk.Label(actions,
                 text="Double-clic → copier le mot de passe dans le presse-papier",
                 font=FONT_SMALL, bg=BG_DARK, fg=TEXT_DIM).pack(side="right")

    def _refresh_list(self, *_):
        if not hasattr(self, 'tree'):
            return
        query = self.search_var.get().lower() if hasattr(self, 'search_var') else ""
        self.tree.delete(*self.tree.get_children())
        self._show_pw_state = {}
        self.filtered = [e for e in self.entries
                         if query in e["site"].lower()
                         or query in e["username"].lower()]
        for i, e in enumerate(self.filtered):
            pw_display = "●" * min(len(e["password"]), 12)
            self.tree.insert("", "end", iid=str(i),
                             values=(e["site"], e["username"],
                                     pw_display, e.get("created", "")))
            self._show_pw_state[str(i)] = False

        # Mettre à jour le compteur sidebar
        for w in self.winfo_children():
            if isinstance(w, tk.Frame):
                for sub in w.winfo_children():
                    if isinstance(sub, tk.Label) and "entrée" in (sub.cget("text") or ""):
                        sub.config(text=f"{len(self.entries)} entrée(s)")

    def _get_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Sélection", "Veuillez sélectionner une entrée.")
            return None, None
        iid = sel[0]
        entry = self.filtered[int(iid)]
        return iid, entry

    def _on_select(self, _event):
        pass

    def _on_double_click(self, _event):
        iid, entry = self._get_selected()
        if entry:
            self.clipboard_clear()
            self.clipboard_append(entry["password"])
            self._flash_status("✅ Mot de passe copié !")

    def _toggle_password(self):
        iid, entry = self._get_selected()
        if not entry:
            return
        showing = self._show_pw_state.get(iid, False)
        self._show_pw_state[iid] = not showing
        new_val = entry["password"] if not showing else "●" * min(len(entry["password"]), 12)
        self.tree.set(iid, "password", new_val)

    def _copy_password(self):
        iid, entry = self._get_selected()
        if not entry:
            return
        self.clipboard_clear()
        self.clipboard_append(entry["password"])
        self._flash_status("✅ Mot de passe copié dans le presse-papier !")

    def _delete_entry(self):
        iid, entry = self._get_selected()
        if not entry:
            return
        if messagebox.askyesno("Confirmer",
                               f"Supprimer l'entrée pour « {entry['site']} » ?",
                               icon="warning"):
            self.entries.remove(entry)
            self._save_data()
            self._refresh_list()
            self._flash_status("🗑 Entrée supprimée.")

    def _edit_entry(self):
        iid, entry = self._get_selected()
        if not entry:
            return
        self._tab_add(edit_entry=entry)

    def _flash_status(self, msg):
        """Affiche un message temporaire en bas à droite."""
        popup = tk.Toplevel(self)
        popup.overrideredirect(True)
        popup.configure(bg=ACCENT)
        x = self.winfo_x() + self.winfo_width() - 320
        y = self.winfo_y() + self.winfo_height() - 70
        popup.geometry(f"300x44+{x}+{y}")
        tk.Label(popup, text=msg, font=FONT_BTN,
                 bg=ACCENT, fg="white", pady=10).pack()
        popup.after(2000, popup.destroy)

    # ════════════════════════════════════════════════════════════════════════
    # ONGLET : AJOUTER / MODIFIER
    # ════════════════════════════════════════════════════════════════════════
    def _tab_add(self, edit_entry=None):
        self._highlight_nav(1)
        self._clear_content()

        title = "Modifier l'entrée" if edit_entry else "Ajouter un mot de passe"

        header = tk.Frame(self.content, bg=BG_DARK)
        header.pack(fill="x", padx=28, pady=(24, 20))
        tk.Label(header, text=title,
                 font=("Segoe UI", 18, "bold"),
                 bg=BG_DARK, fg=TEXT_MAIN).pack(side="left")

        card = tk.Frame(self.content, bg=BG_CARD,
                        highlightbackground=BORDER, highlightthickness=1)
        card.pack(padx=28, fill="x")

        inner = tk.Frame(card, bg=BG_CARD)
        inner.pack(padx=32, pady=28, fill="x")

        fields = {}

        def make_field(parent, label_text, default="", secret=False):
            tk.Label(parent, text=label_text, font=FONT_LABEL,
                     bg=BG_CARD, fg=ACCENT2).pack(anchor="w", pady=(10, 2))
            frame = tk.Frame(parent, bg=BG_INPUT,
                             highlightbackground=BORDER, highlightthickness=1)
            frame.pack(fill="x", ipady=4)
            var = tk.StringVar(value=default)
            entry = tk.Entry(frame, textvariable=var,
                             show="●" if secret else "",
                             font=FONT_MONO if secret else FONT_INPUT,
                             bg=BG_INPUT, fg=TEXT_MAIN,
                             insertbackground=ACCENT, relief="flat", bd=6)
            entry.pack(side="left", fill="x", expand=True)
            if secret:
                show_v = tk.BooleanVar(value=False)
                def _toggle(e=entry, v=show_v):
                    e.config(show="" if v.get() else "●")
                tk.Checkbutton(frame, text="👁", variable=show_v,
                               command=_toggle,
                               bg=BG_INPUT, fg=TEXT_DIM,
                               activebackground=BG_INPUT,
                               selectcolor=BG_INPUT, relief="flat",
                               cursor="hand2").pack(side="right", padx=4)
            return var, entry

        site_var, site_e    = make_field(inner, "🌐  Nom du site / service",
                                         edit_entry["site"]     if edit_entry else "")
        user_var, user_e    = make_field(inner, "👤  Nom d'utilisateur / Email",
                                         edit_entry["username"] if edit_entry else "")
        pw_var,   pw_e      = make_field(inner, "🔑  Mot de passe",
                                         edit_entry["password"] if edit_entry else "",
                                         secret=True)

        # Bouton générer dans le champ mot de passe
        gen_btn = tk.Button(pw_e.master, text="⚡ Générer",
                            command=lambda: pw_var.set(self._generate_pw()),
                            font=("Segoe UI", 9), bg=ACCENT, fg="white",
                            activebackground=ACCENT2, relief="flat",
                            cursor="hand2", padx=8)
        gen_btn.pack(side="right", padx=4)

        msg_var = tk.StringVar()
        msg_lbl = tk.Label(inner, textvariable=msg_var, font=FONT_SMALL,
                           bg=BG_CARD, fg=DANGER)
        msg_lbl.pack(pady=(12, 0), anchor="w")

        btn_row = tk.Frame(inner, bg=BG_CARD)
        btn_row.pack(pady=(16, 0), anchor="e")

        def on_save():
            site = site_var.get().strip()
            user = user_var.get().strip()
            pw   = pw_var.get()
            if not site:
                msg_var.set("⚠ Le nom du site est obligatoire.")
                return
            if not user:
                msg_var.set("⚠ Le nom d'utilisateur est obligatoire.")
                return
            if not pw:
                msg_var.set("⚠ Le mot de passe est obligatoire.")
                return
            new_entry = {
                "site":     site,
                "username": user,
                "password": pw,
                "created":  edit_entry["created"] if edit_entry else datetime.now().strftime("%d/%m/%Y %H:%M"),
            }
            if edit_entry:
                idx = self.entries.index(edit_entry)
                self.entries[idx] = new_entry
            else:
                self.entries.append(new_entry)
            self._save_data()
            self._flash_status("✅ Entrée enregistrée !")
            self._tab_list()

        tk.Button(btn_row, text="Annuler",
                  command=self._tab_list,
                  font=FONT_BTN, bg=BG_INPUT, fg=TEXT_MAIN,
                  activebackground=BORDER, relief="flat",
                  cursor="hand2", padx=14, pady=8).pack(side="left", padx=(0, 8))

        tk.Button(btn_row,
                  text="Enregistrer ✓" if edit_entry else "Ajouter ✓",
                  command=on_save,
                  font=FONT_BTN, bg=ACCENT, fg="white",
                  activebackground=ACCENT2, relief="flat",
                  cursor="hand2", padx=14, pady=8).pack(side="left")

        site_e.focus_set()

    # ════════════════════════════════════════════════════════════════════════
    # ONGLET : GÉNÉRATEUR
    # ════════════════════════════════════════════════════════════════════════
    def _tab_generate(self):
        self._highlight_nav(2)
        self._clear_content()

        header = tk.Frame(self.content, bg=BG_DARK)
        header.pack(fill="x", padx=28, pady=(24, 20))
        tk.Label(header, text="Générateur de mot de passe",
                 font=("Segoe UI", 18, "bold"),
                 bg=BG_DARK, fg=TEXT_MAIN).pack(side="left")

        card = tk.Frame(self.content, bg=BG_CARD,
                        highlightbackground=BORDER, highlightthickness=1)
        card.pack(padx=28, fill="x")
        inner = tk.Frame(card, bg=BG_CARD)
        inner.pack(padx=32, pady=28, fill="x")

        # Longueur
        tk.Label(inner, text="Longueur du mot de passe",
                 font=FONT_LABEL, bg=BG_CARD, fg=ACCENT2).pack(anchor="w")
        len_frame = tk.Frame(inner, bg=BG_CARD)
        len_frame.pack(fill="x", pady=(4, 16))
        len_var = tk.IntVar(value=16)
        len_lbl = tk.Label(len_frame, textvariable=len_var,
                           font=("Segoe UI", 14, "bold"),
                           bg=BG_CARD, fg=ACCENT, width=3)
        len_lbl.pack(side="right")
        scale = tk.Scale(len_frame, from_=8, to=64,
                         variable=len_var, orient="horizontal",
                         bg=BG_CARD, fg=TEXT_MAIN, troughcolor=BG_INPUT,
                         activebackground=ACCENT, highlightthickness=0,
                         sliderrelief="flat", length=340)
        scale.pack(side="left", fill="x", expand=True)

        # Options
        opts_frame = tk.Frame(inner, bg=BG_CARD)
        opts_frame.pack(fill="x", pady=(0, 16))

        use_upper  = tk.BooleanVar(value=True)
        use_lower  = tk.BooleanVar(value=True)
        use_digits = tk.BooleanVar(value=True)
        use_syms   = tk.BooleanVar(value=True)

        def make_check(parent, text, var):
            cb = tk.Checkbutton(parent, text=text, variable=var,
                                font=FONT_SUB, bg=BG_CARD, fg=TEXT_MAIN,
                                activebackground=BG_CARD,
                                selectcolor=ACCENT, relief="flat",
                                cursor="hand2")
            cb.pack(side="left", padx=(0, 20))

        make_check(opts_frame, "A–Z  Majuscules", use_upper)
        make_check(opts_frame, "a–z  Minuscules", use_lower)
        make_check(opts_frame, "0–9  Chiffres",   use_digits)
        make_check(opts_frame, "!@#  Symboles",   use_syms)

        # Résultat
        result_frame = tk.Frame(inner, bg=BG_INPUT,
                                highlightbackground=ACCENT, highlightthickness=1)
        result_frame.pack(fill="x", ipady=6, pady=(8, 16))
        result_var = tk.StringVar()
        tk.Entry(result_frame, textvariable=result_var,
                 font=("Consolas", 15, "bold"),
                 bg=BG_INPUT, fg=SUCCESS,
                 insertbackground=ACCENT, relief="flat",
                 bd=8, state="readonly").pack(fill="x")

        def do_generate():
            alphabet = ""
            if use_upper.get():  alphabet += string.ascii_uppercase
            if use_lower.get():  alphabet += string.ascii_lowercase
            if use_digits.get(): alphabet += string.digits
            if use_syms.get():   alphabet += "!@#$%^&*()-_=+[]{}|;:,.<>?"
            if not alphabet:
                alphabet = string.ascii_letters + string.digits
            pw = "".join(secrets.choice(alphabet) for _ in range(len_var.get()))
            result_var.set(pw)

        do_generate()

        btn_row = tk.Frame(inner, bg=BG_CARD)
        btn_row.pack(anchor="w")

        tk.Button(btn_row, text="🔄  Régénérer",
                  command=do_generate,
                  font=FONT_BTN, bg=BG_INPUT, fg=TEXT_MAIN,
                  activebackground=BORDER, relief="flat",
                  cursor="hand2", padx=14, pady=8).pack(side="left", padx=(0, 8))

        tk.Button(btn_row, text="📋  Copier",
                  command=lambda: (self.clipboard_clear(),
                                   self.clipboard_append(result_var.get()),
                                   self._flash_status("✅ Copié !")),
                  font=FONT_BTN, bg=ACCENT, fg="white",
                  activebackground=ACCENT2, relief="flat",
                  cursor="hand2", padx=14, pady=8).pack(side="left")

    def _generate_pw(self, length=16):
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*-_=+"
        return "".join(secrets.choice(alphabet) for _ in range(length))

    # ════════════════════════════════════════════════════════════════════════
    # PERSISTANCE
    # ════════════════════════════════════════════════════════════════════════
    def _save_data(self):
        data = json.dumps(self.entries, ensure_ascii=False)
        encrypted = encrypt_data(data, self.master_password)
        get_data_path().write_text(encrypted, encoding="ascii")

    def _load_data(self, password):
        raw = get_data_path().read_text(encoding="ascii")
        data = decrypt_data(raw, password)
        self.entries = json.loads(data)

    def _lock(self):
        self.master_password = None
        self.entries = []
        self._show_login_screen()


# ── Lancement ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = VaultApp()
    app.mainloop()
